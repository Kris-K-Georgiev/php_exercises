
<?php

declare(strict_types=1);

require '../vendor/autoload.php';

use Training2025\Models\Member;
use Training2025\Models\PremiumMember;
use Training2025\Services\MemberManager;

$manager = new MemberManager([
new Member('Kris', 'kris@mail.com'),
new PremiumMember('ivan','ivan@mail.com'),
]);

if($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if($action === 'add') {
        $member = $_POST['member'];
        $email = $_POST['email'];
        $type = $_POST['type'];
        
        if($member && $email) {
        $newMember = $type === 'premium' 
            ? new PremiumMember($member, $email) 
            : new Member($member, $email);

            $manager->addMember($newMember);
            echo "<p>Member added: {$newMember->getName()} ({$newMember->getEmail()}) - {$newMember->getMembershipType()}</p>";
        } else {
            echo "<p>Please fill in all fields.</p>";
        }
    } else if ($action === 'remove') {
        $email = $_POST['remove_email'] ?? '';
        if($manager->removeByEmail($email)) {
            echo "<p>Member with email {$email} removed.</p>";
        } else {
            echo "<p>No member found with email {$email}.</p>";
        }
    }
}

    $member = $manager->getMembers();
?>

<html>
    <title>GymMembershipApp</title>
    <link rel="stylesheet" href="style.css">
<body>
    <h1>Gym Membership</h1>
    <table>
        <thead>
            <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Membership Type</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($member as $m): ?>
                <tr>
                    <td><?php echo $m->getName(); ?></td>
                    <td><?php echo $m->getEmail(); ?></td>
                    <td><?php echo $m->getMembershipType(); ?></td>
                </tr>
            <?php endforeach; ?>
    </table>

    <h2>Add Member</h2>
    <form method="POST">
        <input type="hidden" name="action" value="add">
        Name: <input type="text" name="member" required placeholder="Enter Name"><br>
        Email: <input type="email" name="email" required placeholder="Enter Email"><br>
        Membership Type:
        <select name="type">
            <option value="standard">Standard</option>
            <option value="premium">Premium</option>
        </select><br>
        <input type="submit" value="Add Member"></form>
        <h2>Remove Member</h2>
        <form method="POST">
            <input type="hidden" name="action" value="remove">
            <label>Email:</label>
            <input type="email" name="remove_email" required placeholder="Email to remove">
            <input type="submit" value="Remove Member" class="remove">
        </form>
    </body>
</html>