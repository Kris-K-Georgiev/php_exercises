<?php

declare(strict_types=1);

namespace Training2025\Interfaces;

interface MemberInterface
{
    public function getName(): string;

    public function getMembershipType(): string;
}
