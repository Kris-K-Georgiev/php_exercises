<?php

declare(strict_types=1);

namespace Training2025\Models;

use Training2025\Interfaces\MemberInterface;

class Member implements MemberInterface
{
    protected  $name;
        
    protected  $email;

    protected  $membership = 'standard'; 

    public function __construct($name, $email)
    {   $this->name = $name;
        $this->email = $email;
    }

    public function getName(): string
    {
        return $this->name;
    }

    public function getEmail(): string
    {
        return $this->email;
    }
    
    public function getMembershipType(): string
    {
        return $this->membership;
    }
}
