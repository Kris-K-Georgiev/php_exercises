<?php

declare(strict_types=1);

namespace Training2025\Models;

use Training2025\Models\Member;

class PremiumMember extends Member
{
    protected  $membership = 'premium';

    public function getPerks(): array
    {
        return ['Spa', 'Sauna', 'Personal Trainer'];
    }
}
