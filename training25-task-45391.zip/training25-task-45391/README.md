# Gym Membership Management System — Training2025

[![PHP](https://img.shields.io/badge/PHP-8.0%2B-blue)](https://www.php.net/)
![PSR Standards](https://img.shields.io/badge/PSR-1%20%26%2012-brightgreen)


## Table of Contents

1. [System Overview](#system-overview)  
2. [Architecture Diagram](#architecture-diagram)  
3. [Project Structure](#project-structure)  
4. [PSR-1 to PSR-12 Compliance](#psr-1--psr-12-compliance)  
5. [Class Reference](#class-reference)  
6. [Installation](#installation)  
7. [Usage Guide](#usage-guide)  
8. [Configuration](#configuration)  
9. [Troubleshooting](#troubleshooting)  
10. [License](#license)  
11. [Contact](#contact)  
12. [System Requirements & Dependencies](#system-requirements--dependencies)  


## System Overview

This is a clean and modern Object-Oriented PHP application for managing gym memberships using Standard and Premium member types.

### Key Features:

- Fully compliant with PSR-1 to PSR-12 standards  
- PSR-4 autoloading implemented via Composer  
- Clean and user-friendly web interface  
- Real-time member listing  
- Modular and scalable architecture  



## Architecture Diagram

![uml diagram](image.png)

## Project Structure

**<u>UPDATE !!!</u>** As of the latest version, all source code has been moved from the `Kgeorgiev\GymMembershipApp` namespace to the root-level `Training2025/` folder. This change simplifies the directory structure and improves clarity.

```

Training2025/
│
├── Models/
│   ├── Member.php
│   ├── PremiumMember.php
│   └── MemberInterface.php
│
├── Services/
│   └── MemberManager.php
│
├── public/
│   ├── index.php
│   └── style.css
│
├── vendor/
├── composer.json
└── README.md
```

### PSR-1 to PSR-12: Applied Standards and Code Refactoring

#### **PSR-1 (Basic Coding Standard)**

* All PHP files start with the `<?php` tag only (short tags are not used).
* Files are encoded in UTF-8 without BOM.
* Class names follow **StudlyCaps** (e.g., `Member`, `PremiumMember`).
* Method names follow **camelCase** (e.g., `getName()`, `getMembershipType()`).

**Changes made:**

* Renamed classes and methods to follow the correct naming conventions (e.g., `getname()` → `getName()`).
* Removed any usage of short PHP tags.


#### **PSR-2 & PSR-12 (Coding Style Guidelines)**

* Indentation uses **4 spaces** (no tabs).
* Opening curly braces `{` are placed on a **new line** for classes, functions, and control structures.
* All methods declare parameter and return types (`getName(): string`).
* All properties and methods have an explicit visibility (`public`, `protected`, `private`).
* Maximum line length is 120 characters.
* One space is required after control keywords like `if`, `elseif`, `else`, `foreach`, etc.
* Control structures use braces on a **new line**.
* A blank line follows each `namespace` and `use` declaration.
* Unnecessary blank lines and inconsistent indentation are removed.

**Changes made:**

* Reformatted all code using 4-space indentation.
* Adjusted brace placement to a new line.
* Added `declare(strict_types=1);` at the top of each file.
* Specified argument and return types for methods.
* Explicitly declared visibility for all properties and methods.
* Trimmed lines longer than 120 characters.
* Added blank lines after `namespace` and `use`.
* Rewritten conditionals with proper spacing and structure.

#### **PSR-4 (Autoloading Standard)**

* Namespace reflects the directory structure.
* Autoloading is handled by **Composer**.
* Flattened directory structure (`Kgeorgiev\GymMembershipApp\Models` → `Training2025\Models`).

**Changes made:**

* Moved classes under the new namespace `Training2025`.
* Refactored directory structure to match namespace hierarchy.
* Added `require '../vendor/autoload.php';` in the entry file to enable autoloading.

#### **PSR-6, PSR-7, PSR-11 and Others**

These are **not applicable** to this project as they relate to caching, HTTP messages, and dependency injection.

>**!!!** For a full list of PSRs, visit the [PHP-FIG website](https://www.php-fig.org/psr/).


### Code File Refactoring Overview

#### **Main Entry (index.php)**

* Added `declare(strict_types=1);`.
* Enabled Composer autoload with `require '../vendor/autoload.php';`.
* Replaced hardcoded `require` statements with `use` and proper namespacing.
* Refactored `if` / `elseif` / `else` blocks to follow PSR-12 formatting.
* Used null coalescing operator (`??`) for default values.
* Used strict comparisons (`===`).
* Removed closing PHP tags (`?>`).
* Clean separation between PHP logic and HTML output.

#### **Interface File (MemberInterface.php)**

* Added `declare(strict_types=1);` if missing.
* Namespace updated to `Training2025\Interfaces`.
* Clear method declarations with type hints.

#### **Model Files (Member.php, PremiumMember.php)**

* Enforced `declare(strict_types=1);`.
* Namespace adjusted to reflect directory.
* Added visibility and typed properties.
* All methods include return types.
* Constructors accept typed parameters.
* Proper use of `protected` for shared class properties.
* Fully PSR-12 formatted.


#### **Service Class (MemberManager.php)**

* Added `declare(strict_types=1);`.
* Updated namespace and `use` statements.
* Explicitly typed array properties.
* All method arguments and return values are typed.
* PSR-12 compliant formatting.
* Added DocBlocks for property arrays and method returns.

#### **What Was Improved? - Summary**

| Refactoring Group           | Before                          | After                                             |
| --------------------------- | ------------------------------- | ------------------------------------------------- |
| **PHP Declaration**         | No `declare(strict_types=1);`   | Every file starts with `declare(strict_types=1);` |
| **Namespace & Autoload**    | Deep, inconsistent namespaces   | Flat PSR-4 compliant namespace with Composer      |
| **Naming Conventions**      | Non-standard class/method names | `StudlyCaps` for classes, `camelCase` for methods |
| **Visibility & Typing**     | No visibility or types          | Full visibility and type hinting                  |
| **Indentation & Braces**    | Mixed formatting and tab usage  | 4-space indent, new-line braces                   |
| **Conditionals Formatting** | No spacing, inline braces       | Proper spacing and brace formatting               |
| **Documentation**           | Missing DocBlocks               | Added method/property-level documentation         |
| **HTML Separation**         | Mixed logic and HTML            | Cleanly separated PHP logic and HTML              |

---

### **Specific Code Examples**

#### **1. PHP Opening Tag and `strict_types`**

**Before:**
```php
<?php
// Before: Missing strict type enforcement
// No declare(strict_types=1);
?>
```

**After:**

```php
<?php
// Added strict type declaration for type safety
declare(strict_types=1);

// After: No closing PHP tag to avoid accidental output
```

#### **2. Namespace and Autoloading**

```php
// Before: Deep, verbose namespace structure
namespace Kgeorgiev\GymMembershipApp\Models;
use Kgeorgiev\GymMembershipApp\Interfaces\MemberInterface;
```

```php
// After: Simplified and PSR-4-compliant namespace
namespace Training2025\Models;
use Training2025\Interfaces\MemberInterface;
```


#### **3. Class and Method Naming**

```php
// Before: Method name not using camelCase, violating PSR-1
class Member implements MemberInterface{
    public function getname(){
        return $this->name;
    }
}
```

```php
// After: Method uses camelCase, properly formatted
class Member implements MemberInterface
{
    public function getName(): string
    {
        return $this->name;
    }
}
```


#### **4. Visibility and Typing**

```php
// Before: No visibility or type declaration
private $name;
public function getName() {
    return $this->name;
}
```

```php
// After: Property has visibility and a type; method has return type
protected string $name;

public function getName(): string
{
    return $this->name;
}
```

#### **5. Indentation and Braces**

```php
// Before: Inconsistent indentation, opening brace on same line
function getEmail(){
return $this->email; }
```

```php
// After: 4-space indentation, braces on new line per PSR-12
public function getEmail(): string
{
    return $this->email;
}
```

#### **6. Control Structures**

```php
// Before: Else if used instead of elseif, braces on new lines
if($_SERVER['REQUEST_METHOD'] === 'POST') 
{
    if($action === 'add') 
    {
        // ...
    } 
    else if($action === 'remove') 
    {
        // ...
    } 
    else
     {
        // ...
    }
}
```

```php
// After: Proper spacing after control keywords, braces not on new lines
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($action === 'add') {
        // ...
    } 
    elseif ($action === 'remove') {
        // ...
    } else {
        // ...
    }
}
```

#### **7. Composer Autoload**

```php
// Before: Manual file inclusion (not shown)
```

```php
// After: PSR-4 autoload via Composer
require '../vendor/autoload.php';
```

#### **8. DocBlocks and Array Types**

```php
// Before: No documentation or array type hint
private array $members = [];
```

```php
// After: DocBlock specifies array contents, improving IDE support and clarity
/**
 * @var Member[]
 */
private array $members = [];
```


#### **9. Method Parameter and Return Types**

```php
// Before: No return type hint
public function addMember(Member $member){
    $this->members[] = $member;
}
```

```php
// After: Return type `void` explicitly declared
public function addMember(Member $member): void
{
    $this->members[] = $member;
}
```

#### **10. Null-Coalescing Operator**

```php
// Before: Verbose null check with ternary
$action = isset($_POST['action']) ? $_POST['action'] : '';
```

```php
// After: Modern short syntax using ?? (null coalescing)
$action = $_POST['action'] ?? '';
```


#### **11. Conditional Shortening**

```php
// Before: Traditional if/else assignment
if ($type === 'premium') {
    $newMember = new PremiumMember($member, $email);
} else {
    $newMember = new Member($member, $email);
}
```

```php
// After: Shortened ternary operator assignment
$newMember = $type === 'premium'
    ? new PremiumMember($member, $email)
    : new Member($member, $email);
```



## Class Reference

### MemberInterface

```php
public function getName(): string;
public function getMembershipType(): string;
````

### Member

Properties:

* `string $name`
* `string $email`
* `string $membership = "standard"`

Methods:

```php
__construct(string $name, string $email)
getName(): string
getEmail(): string
getMembershipType(): string
```

### PremiumMember

Properties:

* `string $membership = "premium"`

Methods:

```php
getPerks(): array
```

### MemberManager

Properties:

* `Member[] $members`

Methods:

```php
addMember(Member $member): void
removeByEmail(string $email): bool
getMembers(): array
```


## Installation

### Requirements

* PHP 8.0 or higher
* Composer 2.0+

### Steps

1. Clone the repository:

```bash
git clone https://github.com/yourusername/Training2025.git
cd Training2025
```

2. Install Composer dependencies:

```bash
composer install
```

3. Start the built-in PHP server:

```bash
php -S localhost:8000 -t public/
```

4. Open in your browser:

```
http://localhost:8000
```


## Usage Guide

### Web Interface Features:

* Add new member (Standard or Premium)
* Remove existing member by email
* View all members in a table

### HTTP Parameters

| Action        | Method | Parameters        |
| ------------- | ------ | ----------------- |
| Add Member    | POST   | name, email, type |
| Remove Member | POST   | remove\_email     |

**Sample POST (Add Member):**

```http
POST / HTTP/1.1
Content-Type: application/x-www-form-urlencoded

name=Jane&email=jane@example.com&type=premium
```


## Configuration

### Initial Members

You can define default members in `public/index.php`:

```php
$manager = new MemberManager([
    new Member('Admin', 'admin@example.com'),
    new PremiumMember('VIP', 'vip@example.com')
]);
```


## Troubleshooting

| Issue                   | Solution                                                             |
| ----------------------- | -------------------------------------------------------------------- |
| Class not found         | Run `composer dump-autoload`                                         |
| Form not submitting     | Ensure form `name` attributes match PHP variables                    |
| Style not loading       | Check path to `style.css` in `public/`                               |
| PSR code style warnings | Use [PHP\_CodeSniffer](https://github.com/squizlabs/PHP_CodeSniffer) |


## System Requirements & Dependencies

### System Requirements

| Component | Version | Required |
| --------- | ------- | -------- |
| PHP       | 8.0+    | Yes      |
| Composer  | 2.0+    | Yes      |

### External Dependencies (Composer Packages)

| Package              | Version | Purpose                           |
| -------------------- | ------- | --------------------------------- |
| `phpunit/phpunit`    | ^9.5    | Unit testing framework (optional) |
| `psr/log`            | ^1.1    | PSR logging interface             |
| `monolog/monolog`    | ^2.0    | Logging library (if used)         |
| `symfony/var-dumper` | ^5.0    | Improved debugging output         |

> **Note:** Adjust this list according to your actual `composer.json` dependencies.


## License

See **LICENSE** for details.


## Contact

| Type  | Info                                                    |
| ----- | ------------------------------------------------------- |
| Email | [kgeorgiev@sprintax.com](mailto:kgeorgiev@sprintax.com) |

---

> **_Updated_ <u>exercise 3</u> _for_ <u>exercise 4</u> _by Kristian Georgiev_**
> PSR-compliant and simplified project folder for clarity and scalability
