<?php
namespace Kgeorgiev\GymMembershipApp\Interfaces;
    interface MemberInterface{
        public function getName(): string;
        public function getMembershipType(): string;
    }
?>