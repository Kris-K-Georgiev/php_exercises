<?php
namespace Kgeorgiev\GymMembershipApp\Services;

use Kgeorgiev\GymMembershipApp\Models\Member;
    class MemberManager{
        /**
         * @var Member[]
         */
        private array $members = [];
        
        public function __construct(array $initialMembers = []){
            $this->members = $initialMembers;
        }

        public function addMember(Member $member): void{
            $this->members[] = $member;
        }

        /**
         * @return Member[]
         */
        public function getMembers(): array{
            return $this->members;
        }

        public function findByEmail(string $email): ?Member {
            foreach ($this->members as $member) {
                if ($member->getEmail() === $email) {
                    return $member;
                }
            }
            return null;
        }

        public function removeByEmail(string $email): bool {
            foreach ($this->members as $key => $member) {
                if ($member->getEmail() === $email) {
                    unset($this->members[$key]);
                    return true;
                }
            }
            return false;
        }

    }
?>