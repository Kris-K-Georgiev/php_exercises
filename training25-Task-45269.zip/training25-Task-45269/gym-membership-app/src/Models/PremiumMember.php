<?php
namespace Kgeorgiev\GymMembershipApp\Models;

use Kgeorgiev\GymMembershipApp\Models\Member;
    class PremiumMember extends Member{
        protected string $membership = 'premium';

        public function getPerks(): array{
            return ['Spa', 'Sauna', 'Personal Trainer'];
        }
    }
?>