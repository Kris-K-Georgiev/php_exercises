<?php
namespace Kgeorgiev\GymMembershipApp\Models;

use Kgeorgiev\GymMembershipApp\Interfaces\MemberInterface;
    class Member implements MemberInterface{
        protected string $name;
        protected string $email;
        protected string $membership = 'standard'; 

        public function __construct(string $name, string $email){
            $this->name = $name;
            $this->email = $email;
        }

        public function getName(): string{
            return $this->name;
        }

        public function getEmail(): string{
            return $this->email;
        }
        public function getMembershipType(): string{
            return $this->membership;
        }
    }
?>