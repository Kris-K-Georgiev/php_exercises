# Training25

## Project Information

**Technologies Used:**
- PHP 8+
- Composer (for autoloading and dependency management)
- HTML/CSS (for frontend forms and display)
- PSR-4 autoloading (namespace mapping)

**Project Structure:**
- `src/` – PHP classes, models, interfaces, and services
- `public/` – public files (index.php, assets)
- `vendor/` – Composer autoload and dependencies

**How to Run the Application:**
1. Make sure you have PHP (8+) and Composer installed.
2. Open a terminal in the project folder and run:
   ```sh
   composer install
   ```
   If you add new classes, run:
   ```sh
   composer dump-autoload
   ```
3. Start a local PHP server:
   ```sh
   php -S localhost:8000 -t public
   ```
   Or use XAMPP/MAMP and set the root to the `public/` folder.

4. Open [http://localhost:8000](http://localhost:8000) in your browser.

**Autoloading:**
- All classes use the namespace `Kgeorgiev\GymMembershipApp`.
- Composer loads classes automatically based on the PSR-4 configuration in `composer.json`.

**Features:**
- Add standard and premium members
- Remove member by email
- View member list


***

# My chat with ChatGPT


### Prompt:
>How can I create a class-based PHP application demonstrating inheritance and encapsulation?

**Answer:**
>Creating a class-based PHP application that demonstrates inheritance and encapsulation involves structuring your code using OOP (Object-Oriented Programming) principles. Here's a step-by-step example that includes:

* A base class with private/protected properties (encapsulation)
* Getters and setters for controlled access
* A child class that extends the base class (inheritance)
* An interface


### Example Code

#### Interface – UserInterface.php

```php
namespace App\Interfaces;

interface UserInterface {
    public function getRole(): string;
}
```

#### Base Class – User.php

```php
namespace App\Models;
use App\Interfaces\UserInterface;

class User implements UserInterface {
    private string $name;
    private string $email;
    protected string $role = 'user';

    public function __construct(string $name, string $email) {
        $this->name = $name;
        $this->email = $email;
    }

    public function getName(): string { return $this->name; }
    public function getEmail(): string { return $this->email; }
    public function getRole(): string { return $this->role; }
}
```

#### Child Class – Admin.php

```php
namespace App\Models;

class Admin extends User {
    public function __construct(string $name, string $email) {
        parent::__construct($name, $email);
        $this->role = 'admin';
    }

    public function deleteUser(User $user): string {
        return "{$user->getName()} deleted by admin.";
    }
}
```

#### Main – index.php

```php
require 'vendor/autoload.php';

use App\Models\User;
use App\Models\Admin;

$user = new User('John', 'john@example.com');
$admin = new Admin('Alice', 'admin@example.com');

echo $admin->deleteUser($user);
```

***

### Prompt
>How do I use namespaces and Composer-based autoloading in PHP?

**Answer:**
>To use namespaces and Composer-based autoloading in PHP, follow these steps:

#### Create a Project Structure

your-project/
├── src/
│   └── Models/
│       └── User.php
├── composer.json
└── index.php

#### Add Namespace in Your PHP Classes

```php
<?php
namespace App\Models;

class User {
    public function sayHello() {
        return "Hello from User!";
    }
}
```

#### Set Up Composer Autoloading

```json
{
  "autoload": {
    "psr-4": {
      "App\\": "src/"
    }
  }
}
```
Then run:

```bash
composer dump-autoload
```

This generates the vendor/ directory and autoloader

***

### Prompt:
>How do I get and process a date from an HTML date input field in PHP?

**Answer:**
>The date input provides a string in YYYY-MM-DD format. You can convert it to a timestamp for formatting or calculations.

```php
    $date = $_POST['date']; // e.g., "2025-07-15"
    $timestamp = strtotime($date);
    echo date('d.m.Y', $timestamp); // outputs "15.07.2025"
```

#### Use the Class with Autoloading

```php
<?php
require __DIR__ . '/vendor/autoload.php';

use App\Models\User;

$user = new User();
echo $user->sayHello();
```

#### Result

Hello from User!

***

### Prompt:
>How do I define and use an interface in PHP?

**Answer:**
>Defining and using an interface in PHP is simple and powerful — it allows you to define a contract (a set of methods) that a class must implement.

#### Define the Interface

```php
<?php
interface Animal {
    public function makeSound(): string;
}
```

This says: any class that implements Animal must define the makeSound() method.

#### Implement the Interface in a Class

```php
<?php
class Dog implements Animal {
    public function makeSound(): string {
        return "Woof!";
    }
}
```

#### Use the Class

```php
$dog = new Dog();
echo $dog->makeSound(); // Output: Woof!
```

#### Real Example with Namespace

##### src/Interfaces/Animal.php

```php
<?php
namespace App\Interfaces;

interface Animal {
    public function makeSound(): string;
}
```

##### src/Models/Dog.php

```php
<?php
namespace App\Models;

use App\Interfaces\Animal;

class Dog implements Animal {
    public function makeSound(): string {
        return "Woof!";
    }
}

```
##### index.php
```php
<?php
require 'vendor/autoload.php';

use App\Models\Dog;

$dog = new Dog();
echo $dog->makeSound();

```

***

### Prompt:
>How can I describe class relationships in a PHP application?

**Answer:**
>To describe class relationships in a PHP application, you can use text, UML diagrams, or code comments to explain how classes are connected.

__Here are the main types of class relationships in PHP OOP:__

#### Inheritance (is-a)
A child class inherits from a parent class using extends.

```php
class Animal {}
class Dog extends Animal {} // Dog **is an** Animal
```
_Relationship: Dog → Animal (inherits from)_

#### Interface Implementation (implements)
A class implements an interface, meaning it agrees to define the interface’s methods.

```php
interface Speakable {
    public function speak(): string;
}

class Human implements Speakable {
    public function speak(): string {
        return "Hello!";
    }
}
```

_Relationship: Human → Speakable (implements)_

#### Association (has-a)
A class has a reference to another class (composition/aggregation).

```php
class Engine {}
class Car {
    private Engine $engine; // Car **has an** Engine

    public function __construct() {
        $this->engine = new Engine();
    }
}
```

_Relationship: Car has-a Engine (association)_

#### Dependency (uses)
A class depends on another class temporarily, usually via a method parameter.

```php
class Logger {
    public function log(string $msg) {
        echo $msg;
    }
}

class OrderProcessor {
    public function process(Logger $logger) {
        $logger->log("Order processed");
    }
}
```

_Relationship: OrderProcessor uses Logger (dependency)_

#### Example (Combined)

```php
interface Notifiable {
    public function notify(string $message): void;
}

class EmailService implements Notifiable {
    public function notify(string $message): void {
        echo "Email: $message";
    }
}

class User {
    private Notifiable $notifier;

    public function __construct(Notifiable $notifier) {
        $this->notifier = $notifier;
    }

    public function sendAlert() {
        $this->notifier->notify("You have a new alert!");
    }
}
```
_Relationships:_

* _EmailService implements Notifiable_
* _User depends on Notifiable (via constructor)_
* _Loose coupling through interface_

#### Optional: UML Diagram (Text)
```uml
        +-------------------+
        |   Notifiable      |<<interface>>
        +-------------------+
        | +notify(msg)      |
        +-------------------+
                 ▲
                 |
        +-------------------+
        |  EmailService     |
        +-------------------+
        | +notify(msg)      |
        +-------------------+

        +-------------------+
        |      User         |
        +-------------------+
        | -notifier         |
        +-------------------+
        | +sendAlert()      |
        +-------------------+
```

***

### Prompt: 

>I have this PHP code for adding members in my Gym Membership app:

```php
if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $member = $_POST['member'];
    $email = $_POST['email'];
    $type = $_POST['type'];

    $newMember = $type === 'premium' 
        ? new PremiumMember($member, $email) 
        : new Member($member, $email);

    $manager->addMember($newMember);
}
```
>How can I modify it to also remove a member by email using a form? Can you show me how to implement the remove function and integrate it into my existing code?

### Answer:

>To add member removal functionality, first add a method in your `MemberManager` class:

```php
public function removeByEmail(string $email): bool {
    foreach ($this->members as $key => $member) {
        if ($member->getEmail() === $email) {
            unset($this->members[$key]);
            $this->members = array_values($this->members); // reindex array
            return true;
        }
    }
    return false;
}
```
>Then, add a form for removing members in your HTML:

```html
<form method="POST">
    <input type="hidden" name="action" value="remove">
    <input type="email" name="remove_email" required placeholder="Email to remove">
    <input type="submit" value="Remove Member">
</form>
```

>Finally, modify your PHP script to handle the removal action:

```php
if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $action = $_POST['action'] ?? '';

    if ($action === 'add') {
        // existing add member code
    } elseif ($action === 'remove') {
        $emailToRemove = $_POST['remove_email'] ?? '';
        if ($manager->removeByEmail($emailToRemove)) {
            echo "<p>Member with email {$emailToRemove} removed.</p>";
        } else {
            echo "<p>No member found with email {$emailToRemove}.</p>";
        }
    }
}

```

***

### Prompt:

> I get an error "Class 'Kgeorgiev\GymMembershipApp\Models\PremiumMember' not found". What am I missing?

### Answer: 

>This error usually means Composer’s autoloader can’t find the class file.

>Make sure:

1. Your `composer.json` has the correct PSR-4 autoload section, e.g.:

```json
"autoload": {
    "psr-4": {
        "Kgeorgiev\\GymMembershipApp\\": "src/"
    }
}
```

>Your class files are in the right folder, e.g. src/Models/PremiumMember.php.
You have run composer dump-autoload after adding new classes.
Your namespace declaration at the top of your class files matches the folder structure, e.g.:
namespace Kgeorgiev\GymMembershipApp\Models;
